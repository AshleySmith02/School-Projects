﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baker_Grillers_Group_Project_Part_I.Settings
{
    public partial class CSGOPreferencesUserControl : UserControl
    {
        public CSGOPreferencesUserControl()
        {
            InitializeComponent();
        }
    }
}
