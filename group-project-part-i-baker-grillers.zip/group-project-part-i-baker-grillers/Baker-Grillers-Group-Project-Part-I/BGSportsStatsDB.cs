namespace Baker_Grillers_Group_Project_Part_I
{
    partial class BGSportsStatsDBDataContext
    {
    }
}