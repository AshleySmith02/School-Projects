﻿//using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore;

namespace ASmith_CPT_206_Lab_5_MVC.Data
{
    public class StateApplicationDbContext : DbContext
    {
        //Constructor
        public StateApplicationDbContext(options)
        {

        }
    }
}
